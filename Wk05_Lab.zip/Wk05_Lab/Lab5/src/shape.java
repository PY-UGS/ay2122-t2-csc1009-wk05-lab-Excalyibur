public abstract class shape {
    public shape(double dim1, double dim2, double PI) {

    }
    public abstract double area();
}
